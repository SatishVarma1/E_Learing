
import Container from "./Container";
import './Css/PaidCourses.css';

const PaidCourses = () =>{

    return(
        <div>
            <h2>Paid Courses</h2>
            <Container/>
            <Container/>
        </div>
    );
}

export default PaidCourses;