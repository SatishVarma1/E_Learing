import React from 'react'
 import './Upload.css';
function UploadWork() {
  return (
    <div>
    <img src="/images/CutmLogo.png" alt="centurion img" width="230px" height="110px"></img>
    <h1>Upload Taks and Assignments</h1>
    <div class="bigbox">
      <p>upload from local computer or drive</p>
      <a href="#">upload</a>
    </div>
    </div>
  )
}


export default UploadWork;