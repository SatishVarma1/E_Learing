import React from 'react'
//import './ViewAs.css';
function ViewAssess() {
  return (
    <div>
    <img src="/images/CutmLogo.png" alt="bad" height="75px" width="200px"></img>
    <center>  
        <h1>Assignment</h1>
        <iframe src="\updatedSRS.pdf" 
                width="800" 
                height="900"
                title='ass'>
        </iframe>
    </center>
    </div>
  )
}

export default ViewAssess;