import './Css/Header.css';

const Header = () =>{
    return(
        <div className="header">
            <h2>Cutm</h2>
        </div>
    );

}
export default Header;