import  React  from "react";
import './Scheduleclass';
function Scheduleclass() {
    return (
        <div className="background">
            <div class="adding">
            <label for="sessname"><b>Session Name:</b></label><br></br>
           <input class="in1" type="text" name="name" placeholder=''/><br></br>
           <label for="about"><b>About:</b></label><br></br>
           <input class="in1" type="email" name="email"  placeholder=''/><br></br>
<label for="Sem"><b>Semester:</b></label>
<select name="sem" id="sem">
    <option value="sem1">sem1</option>
  <option value="sem2">sem2</option>
  <option value="sem3">sem3</option>
  <option value="sem4">sem4</option>
  <option value="sem5">sem5</option>
  <option value="sem6">sem6</option>
  <option value="sem7">sem7</option>
  <option value="sem8">sem8</option>
</select>
<br />
<br />
<label for="new"><b>Tutor:</b></label>
<select name="tut" id="tut">
    <option>Dr.Debendra Maharana</option>
  <option>Dr.Ashish Ranjan Dash</option>
  <option>Kirtidev Mahaptro</option>
  <option>Ms.Arya Lopa</option>
  <option>Anshuman Pattnaik</option>
  <option>Abinas Panda</option>
  <option>Dr.Prashant Kumar Mohanty</option>
  <option>Dr.Anita Patra</option>
</select>
<br />
<br />
           <td><label for="time"><b>Time:</b></label></td>
        <td><input type="time"/></td>
        
        <br />
             
<label for="date"><b>Date:</b></label>
<input type="date" id="date" aria-describedby="date-format" name="date" min="2000-01-01" max="3000-01-01" />

           
           <button class="btn btn-primary" type="submit">Add Schedule</button>
            
        <img className='addpic' src="/Images/artadd.png" alt="good or bad" width="540px" height="450px"></img>
    </div>
            </div>
         )
}
export default Scheduleclass;